wynik_4_1 = 0
pierwsza_liczba = '0'

with open("Dane_2205/liczby.txt", "r") as plik:
    liczby = [linia.strip() for linia in plik]

# -------------------- ZADANIE 4_1 ----------------------
def zadanie_4_1(liczba):
    if liczba[0] == liczba[len(liczba)-1]:
        return True
    else:
        return False


for liczba in liczby:
    if zadanie_4_1(liczba):
        if pierwsza_liczba == '0':
            pierwsza_liczba = liczba
        wynik_4_1 += 1

print("Wynik 4.1: ", wynik_4_1)
print("Wynik 4.1 - pierwsza liczba: ", pierwsza_liczba)

# -------------------- ZADANIE 4_2 ----------------------

def zadanie_4_2(liczba):
    czynniki = []
    dzielnik = 2
    while dzielnik * dzielnik <= liczba:
        while liczba % dzielnik == 0:
            czynniki.append(dzielnik)
            liczba = liczba // dzielnik
        dzielnik += 1
    if liczba > 1:
        czynniki.append(liczba)
    return czynniki

maks_czynnikow = 0
liczba_maks_czynnikow = None
maks_roznych_czynnikow = 0
liczba_maks_roznych_czynnikow = None

for liczba in liczby:
    czynniki = zadanie_4_2(int(liczba))
    rozne_czynniki = set(czynniki)

    if len(czynniki) > maks_czynnikow:
        maks_czynnikow = len(czynniki)
        liczba_maks_czynnikow = int(liczba)

    if len(rozne_czynniki) > maks_roznych_czynnikow:
        maks_roznych_czynnikow = len(rozne_czynniki)
        liczba_maks_roznych_czynnikow = int(liczba)

print(f"Wynik 4.2 - najwięcej czynników: {maks_czynnikow} dla {liczba_maks_czynnikow}")
print(f"Wynik 4.2 - najwięcej różnych czynników: {maks_roznych_czynnikow} dla {liczba_maks_roznych_czynnikow}")

# -------------------- ZADANIE 4_3 ----------------------
def zadanie_4_3a(liczby):
    trojki = []

    for i in range(0, len(liczby)):
        liczba_1 = int(liczby[i])
        for j in range(0, len(liczby)):
            if i == j:
                continue
            liczba_2 = int(liczby[j])
            if liczba_2 % liczba_1 == 0:
                for k in range(0, len(liczby)):
                    if i == k or j == k:
                        continue

                    liczba_3 = int(liczby[k])
                    if liczba_3 % liczba_2 == 0:
                        trojki.append([liczba_1, liczba_2, liczba_3])

    return trojki


def zadanie_4_3b(liczby):
    piatki = []

    for i in range(0, len(liczby)):
        liczba_1 = int(liczby[i])
        for j in range(0, len(liczby)):
            if i == j:
                continue
            liczba_2 = int(liczby[j])
            if liczba_2 % liczba_1 == 0:
                for k in range(0, len(liczby)):
                    if i == k or j == k:
                        continue

                    liczba_3 = int(liczby[k])
                    if liczba_3 % liczba_2 == 0:
                        for l in range(0, len(liczby)):
                            if l == k or l == j or l == i:
                                continue
                            liczba_4 = int(liczby[l])
                            if liczba_4 % liczba_3 == 0:
                                for m in range(0, len(liczby)):
                                    if m == l or m == k or m == j or m == i:
                                        continue
                                    liczba_5 = int(liczby[m])
                                    if liczba_5 % liczba_4 == 0:
                                        piatki.append([liczba_1, liczba_2, liczba_3, liczba_4, liczba_5])

    return piatki

dobre_trojki = zadanie_4_3a(liczby)
print("Wynik 4.3a - liczba trójek: ", len(dobre_trojki))
for trojka in dobre_trojki:
    print(trojka)

with open("trojki.txt", "w") as plik2:
    for trojka in dobre_trojki:
        plik2.write(f"{trojka[0]}, {trojka[1]}, {trojka[2]}\n")

dobre_piatki = zadanie_4_3b(liczby)
print("Wynik 4.3b - liczba piatek: ", len(dobre_piatki))
for piatka in dobre_piatki:
    print(piatka)
